// Smooth scroll https://github.com/cferdinandi/smooth-scroll
// new SmoothScroll('a[href*="#"]')